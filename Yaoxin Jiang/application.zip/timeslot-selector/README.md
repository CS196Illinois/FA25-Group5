# Time Slot Selector

A simple, interactive MVP for weekly time slot selection with three states: Empty, Could Do, and Must Do.

## Features

- **90×5 Grid**:
  - 90 rows = Time slots (7:00 AM - 10:00 PM, 10-minute intervals)
  - 5 columns = Weekdays (Monday, Tuesday, Wednesday, Thursday, Friday)
- **Three States**:
  - Empty (0) - White
  - Could Do (1) - Yellow
  - Must Do (2) - Green
- **Time Labels**: Hour markers on the left (7:00, 8:00, 9:00, etc.)
- **Day Labels**: M, T, W, R, F headers
- **Drag to Select**: Click and drag to fill multiple cells at once
- **Drawing Modes**: Choose which state to apply when dragging
- **Click to Cycle**: Click individual cells to cycle through states
- **Clear All**: Reset the entire grid with one click
- **Real-time JSON Output**: Auto-generates JSON on every change
- **Statistics**: Live count of cells in each state
- **Copy to Clipboard**: Easy copy button for JSON output
- **Mobile Support**: Touch events for mobile devices

## Usage

### Running the HTML App

1. Open `index.html` in any modern web browser
2. No server required - runs entirely locally
3. Works offline

### Using the Interface

1. **Select Drawing Mode**: Click one of the mode buttons (Empty, Could Do, Must Do)
2. **Draw on Grid**:
   - Click individual cells to cycle through states
   - Click and drag to fill multiple cells with the current mode
3. **View Output**: JSON updates automatically in the output panel
4. **Copy JSON**: Click "Copy JSON" button to copy to clipboard
5. **Clear All**: Click "Clear All" to reset the entire grid

### JSON Output Format

The output JSON is structured for easy Python parsing:

```json
{
  "data": [
    [0, 0, ..., 1, 1, ..., 0, 0],  // Monday (90 time slots)
    [0, 0, ..., 0, 0, ..., 0, 0],  // Tuesday
    [0, 0, ..., 0, 0, ..., 2, 2],  // Wednesday
    [0, 0, ..., 0, 0, ..., 0, 0],  // Thursday
    [0, 0, ..., 0, 0, ..., 1, 1]   // Friday
  ],
  "shape": [5, 90],
  "description": "2D array compatible with numpy.ndarray - shape (5, 90)",
  "time_info": {
    "start_time": "7:00",
    "end_time": "22:00",
    "interval_minutes": 10,
    "total_slots": 90
  },
  "days": ["M", "T", "W", "R", "F"],
  "states": {
    "0": "empty",
    "1": "soft_preference",
    "2": "hard_preference"
  }
}
```

## Python Integration

### Basic Usage

```python
import json
import numpy as np
from parse_output import parse_json_to_numpy

# Parse JSON string
with open('output.json', 'r') as f:
    json_string = f.read()

arr = parse_json_to_numpy(json_string)
# Result: numpy array of shape (5, 90) with dtype=int
# Rows = days (M, T, W, R, F)
# Cols = time slots (7:00-22:00, 10-min intervals)
```

### Available Functions

The `parse_output.py` script provides:

**Core Functions:**
- `parse_json_to_numpy(json_string)` - Convert JSON to numpy array
- `load_from_file(filepath)` - Load from file
- `print_statistics(arr)` - Print statistics
- `find_time_slots(arr, state)` - Find all slots with specific state

**Filtering Functions:**
- `parseHardFiltering(json_input)` - Convert to binary array with only hard preferences (2→1, others→0)
- `parseSoftFiltering(json_input)` - Convert to binary array with only soft preferences (1→1, others→0)
- `parseHardFilteringFromFile(filepath)` - Load file and apply hard filtering
- `parseSoftFilteringFromFile(filepath)` - Load file and apply soft filtering

**Time/Day Queries:**
- `get_day_column(arr, day)` - Get all time slots for a specific day
- `get_time_range(arr, start_hour, end_hour)` - Extract specific time range
- `slot_to_time(slot_index)` - Convert slot index to time string
- `time_to_slot(time_str)` - Convert time string to slot index

**Statistics:**
- `get_row_statistics(arr)` - Get per-row (time slot) statistics
- `get_day_statistics(arr)` - Get per-day (column) statistics

**File Operations:**
- `save_array_to_file(arr, filepath)` - Save to .npy file
- `export_to_csv(arr, filepath)` - Export to CSV
- `compare_arrays(arr1, arr2)` - Compare two arrays

### Example

```python
from parse_output import *
import numpy as np

# Load data
arr = load_from_file('output.json')

# Print statistics
print_statistics(arr)

# Get statistics by day
day_stats = get_day_statistics(arr)
for stat in day_stats:
    print(f"{stat['day']}: {stat['hard_preference']} hard preference slots")

# Find all "Hard Preference" slots
hard_preference_slots = find_time_slots(arr, 2)
print(f"Found {len(hard_preference_slots)} hard preference time slots")

# Get Monday's schedule
monday = get_day_column(arr, 'Monday')
print(f"Monday has {np.sum(monday == 1)} soft preference slots")

# Extract business hours (9 AM - 5 PM)
business_hours = get_time_range(arr, 9, 17)
print(f"Business hours shape: {business_hours.shape}")

# Time conversions
print(f"Slot 0 starts at: {slot_to_time(0)}")  # 7:00
print(f"9:30 AM is slot: {time_to_slot('9:30')}")  # 15

# Filter to show only hard preferences as binary array
hard_only = parseHardFiltering(arr)
# Result: 0 or 1 array where 1 = hard preference, 0 = everything else
print(f"Total hard preferences: {np.sum(hard_only)}")

# Filter to show only soft preferences as binary array
soft_only = parseSoftFiltering(arr)
# Result: 0 or 1 array where 1 = soft preference, 0 = everything else
print(f"Total soft preferences: {np.sum(soft_only)}")

# Can also filter directly from file
hard_from_file = parseHardFilteringFromFile('output.json')
soft_from_file = parseSoftFilteringFromFile('output.json')

# Export to CSV
export_to_csv(arr, 'timeslots.csv')
```

## File Structure

```
timeslot-selector/
├── index.html          # Main HTML application
├── parse_output.py     # Python parsing utilities
└── README.md          # This file
```

## Technical Details

- **No Dependencies**: Pure HTML, CSS, and JavaScript
- **Grid Size**: 90 rows × 5 columns = 450 cells
- **Time Range**: 7:00 AM - 10:00 PM (15 hours)
- **Time Interval**: 10 minutes per slot
- **Days**: Monday through Friday (M, T, W, R, F)
- **State Values**: 0 (empty), 1 (soft preference), 2 (hard preference)
- **Data Format**: 2D array compatible with `numpy.zeros((5, 90), dtype=int)`
- **JSON Output**: Transposed to shape (5, 90) - rows = days, cols = time slots
- **Cell Dimensions**: 80px wide × 20px tall
- **Browser Compatibility**: Chrome, Firefox, Safari, Edge (modern versions)

## Customization

To change the time range or intervals, modify these constants in `index.html`:

```javascript
const ROWS = 90;           // Time slots (calculated)
const COLS = 5;            // Days of week
const START_HOUR = 7;      // Start at 7:00 AM
const END_HOUR = 22;       // End at 10:00 PM
const INTERVAL_MINUTES = 10;  // 10-minute intervals
const DAYS = ['M', 'T', 'W', 'R', 'F'];  // Weekdays
```

To change colors, modify the CSS:

```css
.cell.state-0 { background-color: #ffffff; } /* Empty */
.cell.state-1 { background-color: #ffc107; } /* Could Do */
.cell.state-2 { background-color: #4caf50; } /* Must Do */
```

## Use Cases

- **Time Availability**: Mark your availability across time slots
- **Schedule Planning**: Plan events across multiple time periods
- **Resource Allocation**: Track resource availability
- **Project Planning**: Mark task priorities
- **Meeting Scheduling**: Find optimal meeting times
- **Shift Planning**: Manage shift preferences

## License

MIT License - Feel free to use and modify as needed.

## Future Enhancements

Potential features for future versions:

- [ ] Save/load grid state to localStorage
- [ ] Export to different formats (CSV, Excel)
- [ ] Import existing data
- [ ] Row/column labels
- [ ] Time range selector
- [ ] Multiple user support
- [ ] Undo/redo functionality
- [ ] Keyboard shortcuts
- [ ] Custom grid dimensions
- [ ] Print view

## Support

For issues or questions, please check the code comments or modify as needed for your use case.
