# Class Schedule Generator

A simple, standalone HTML class schedule generator that displays weekly class schedules based on JSON input.

## Features

- Takes JSON input with class details (title, description, weekdays, time)
- Displays classes in a Monday-Friday weekly calendar view
- No conflict handling needed - classes are displayed as provided
- Shows class title and description (2-3 words) in each block
- Built with vanilla JavaScript and CSS Grid (no external dependencies)

## Usage

1. Open `index.html` in your web browser
2. Edit the JSON in the textarea or use the example data
3. Click "Generate Schedule" to render the calendar

## JSON Format

```json
[
  {
    "title": "Class Name",
    "description": "Short desc",
    "weekdays": ["Monday", "Wednesday", "Friday"],
    "time": "09:00-10:30"
  }
]
```

### Fields

- **title** (string): The class name/subject displayed prominently
- **description** (string): Brief 2-3 word description shown below the title (e.g., course code, room number)
- **weekdays** (array): Days of the week when the class occurs. Valid values:
  - "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
- **time** (string): Class time range in HH:MM-HH:MM format (24-hour)

## Example

```json
[
  {
    "title": "Mathematics",
    "description": "Calculus I",
    "weekdays": ["Monday", "Wednesday", "Friday"],
    "time": "09:00-10:30"
  },
  {
    "title": "Physics",
    "description": "Lab session",
    "weekdays": ["Tuesday", "Thursday"],
    "time": "10:00-12:00"
  },
  {
    "title": "English",
    "description": "Literature",
    "weekdays": ["Monday", "Wednesday"],
    "time": "14:00-15:30"
  }
]
```

## Technical Details

- **No build process required**: Everything works directly in the browser
- **No external dependencies**: Pure vanilla JavaScript and CSS
- Automatically displays the current week (Monday - Friday)
- Classes are color-coded for easy distinction
- Clicking a class shows its full details
- Responsive CSS Grid layout
- Time slots from 7:00 AM to 10:00 PM

## Browser Compatibility

Works in all modern browsers:
- Chrome/Edge 90+
- Firefox 88+
- Safari 14+

## Use Cases

- Student class schedules
- Teacher timetables
- Training course schedules
- Workshop/seminar schedules
- Any recurring weekday event planning

## License

This is a minimal viable product (MVP) example. Use and modify as needed.
